﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataFirst.Models;
namespace DataFirst.Controllers
{
    public class SearchController : Controller
    {
        //
        // GET: /Search/
        private Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult SearchResult(string id)
        {
           // ViewBag.data = id;
          //  var s = from c in db.Registrations where c.userid.Contains(id) select c;
            var s = from c in db.Registrations where c.userid.StartsWith(id) select c;
            return View(s.ToList());
        }
    }
}
