﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataFirst.Models;
namespace DataFirst.Controllers
{
    public class DDLExampleController : Controller
    {
        //
        // GET: /DDLExample/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {

           
            List<SelectListItem> userList = (from p in db.Registrations.AsEnumerable()
                                                 select new SelectListItem
                                                 {
                                                     Text = p.userid,
                                                     Value = p.userid
                                                 }).ToList();


            //Add Default Item at First Position.
            userList.Insert(0, new SelectListItem { Text = "--Select User--", Value = "" });
            

            return View(userList);
        }

        [HttpPost]
        public ActionResult Index(string ddluser)
        {
            var s = (from c in db.Registrations where c.userid.Equals(ddluser) select c).FirstOrDefault();
            ViewBag.data = s.userid + " " + s.password + " " + s.mobileno + " " + s.email;
            List<SelectListItem> userList = (from p in db.Registrations.AsEnumerable()
                                             select new SelectListItem
                                             {
                                                 Text = p.userid,
                                                 Value = p.userid
                                             }).ToList();
            return View(userList);

        }

    }
}
