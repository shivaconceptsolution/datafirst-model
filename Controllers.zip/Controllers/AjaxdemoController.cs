﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataFirst.Models;
namespace DataFirst.Controllers
{
    public class AjaxdemoController : Controller
    {
        //
        // GET: /Ajaxdemo/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Ajaxcode(Stu st)
        {
            

            try
            {
               /* Stu s = new Stu();
                s.ID=st.ID;
                s.NAME=st.Name;
                s.AGE = st.Age.ToString();*/
                db.Stus.Add(st);
                db.SaveChanges();
                return Json(new
                {
                    msg = "Successfully added " + st.NAME
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }  
        }
    }
}
